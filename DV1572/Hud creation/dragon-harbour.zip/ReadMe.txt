DRAGON HARBOUR
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Dragon Harbour isn�t a Uresia-specific font by any stretch, but it�s named for Coatestown, a city that had considerable dragon troubles a few years ago. I�m doing a Coatestown piece right now for a tsunami-relief charity project, so I�ve had both dragons and harbours (note the Canadian spelling!) on the brain. I doodled this font during a writing break while pondering a draft of the city map. This is an all-caps font, but otherwise has a full keyboard set, plus a few of the usual extras. It�s free for non-commercial use; enjoy!

This font is copyright 2005 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for private, non-commercial use. Contact me at sjohn@cumberlandgames.com if you're interested in a licence for public or organizational use.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0
